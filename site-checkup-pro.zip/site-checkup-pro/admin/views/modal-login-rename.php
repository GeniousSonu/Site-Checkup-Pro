<?php
/**
 * Modal: Rename Login URL
 *
 * Configures custom login URL with conflict checks, emergency recovery instructions,
 * and mandatory typed 'CHANGE' confirmation.
 *
 * @package SiteCheckupPro
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wpsg-modal-overlay" id="wpsg-modal-login-rename" style="display: none;">
	<div class="wpsg-modal">
		<div class="wpsg-modal-header">
			<div class="wpsg-modal-title-row">
				<span class="dashicons dashicons-admin-network"></span>
				<h3><?php esc_html_e( 'Change WordPress Login URL', 'site-checkup-pro' ); ?></h3>
			</div>
			<button type="button" class="wpsg-modal-close" data-close-modal>&times;</button>
		</div>

		<div class="wpsg-modal-body">
			<!-- WPS Hide Login Recommendation Box -->
			<div class="wpsg-callout wpsg-callout-info">
				<span class="dashicons dashicons-star-filled"></span>
				<div>
					<strong><?php esc_html_e( 'Recommended Industry Standard:', 'site-checkup-pro' ); ?></strong>
					<p><?php esc_html_e( 'For maximum compatibility with third-party SSO, WooCommerce, and membership plugins, we recommend using WPS Hide Login.', 'site-checkup-pro' ); ?></p>
					<a href="<?php echo esc_url( admin_url( 'plugin-install.php?s=wps-hide-login&tab=search&type=term' ) ); ?>" class="wpsg-btn wpsg-btn-sm wpsg-btn-outline" target="_blank">
						<span class="dashicons dashicons-download"></span> <?php esc_html_e( 'Install WPS Hide Login', 'site-checkup-pro' ); ?>
					</a>
				</div>
			</div>

			<div class="wpsg-callout wpsg-callout-danger">
				<span class="dashicons dashicons-shield"></span>
				<div>
					<strong><?php esc_html_e( 'Emergency Lockout Recovery Safeguard:', 'site-checkup-pro' ); ?></strong>
					<p><?php esc_html_e( 'There is ZERO public query-string backdoor. If you ever lose access to your custom slug, add this constant to wp-config.php via FTP/SSH:', 'site-checkup-pro' ); ?></p>
					<code>define( 'WPSG_DISABLE_LOGIN_RENAME', true );</code>
				</div>
			</div>

			<div class="wpsg-form-group">
				<label class="wpsg-form-label" for="wpsg-input-login-slug"><?php esc_html_e( 'New Secret Login Slug:', 'site-checkup-pro' ); ?></label>
				<div class="wpsg-input-prefix-row">
					<span class="wpsg-input-prefix"><?php echo esc_html( home_url( '/' ) ); ?></span>
					<input type="text" id="wpsg-input-login-slug" class="wpsg-input" placeholder="my-agency-login" autocomplete="off" />
				</div>
				<p class="wpsg-form-help"><?php esc_html_e( 'Do not use standard names like admin, wp-admin, login, or dashboard.', 'site-checkup-pro' ); ?></p>
			</div>

			<div class="wpsg-form-group">
				<label class="wpsg-form-label" for="wpsg-input-login-confirm">
					<?php esc_html_e( 'Type "CHANGE" to confirm you have noted the recovery constant:', 'site-checkup-pro' ); ?>
				</label>
				<input type="text" id="wpsg-input-login-confirm" class="wpsg-input wpsg-input-confirm" placeholder="CHANGE" autocomplete="off" />
			</div>
		</div>

		<div class="wpsg-modal-footer">
			<button type="button" class="wpsg-btn wpsg-btn-outline" data-close-modal><?php esc_html_e( 'Cancel', 'site-checkup-pro' ); ?></button>
			<button type="button" class="wpsg-btn wpsg-btn-danger" id="wpsg-btn-confirm-login-rename" disabled>
				<span class="dashicons dashicons-lock"></span> <?php esc_html_e( 'Activate Custom Login URL', 'site-checkup-pro' ); ?>
			</button>
		</div>
	</div>
</div>
