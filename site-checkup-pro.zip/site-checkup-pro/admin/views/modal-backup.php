<?php
/**
 * Modal: Backup Gating & Confirmation
 *
 * Prompts user to trigger a fresh backup before executing file-modifying tasks.
 *
 * @package SiteCheckupPro
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wpsg-modal-overlay" id="wpsg-modal-backup" style="display: none;">
	<div class="wpsg-modal">
		<div class="wpsg-modal-header">
			<div class="wpsg-modal-title-row">
				<span class="dashicons dashicons-backup"></span>
				<h3><?php esc_html_e( 'Recent Backup Required', 'site-checkup-pro' ); ?></h3>
			</div>
			<button type="button" class="wpsg-modal-close" data-close-modal>&times;</button>
		</div>

		<div class="wpsg-modal-body">
			<div class="wpsg-callout wpsg-callout-warning">
				<span class="dashicons dashicons-shield-alt"></span>
				<div>
					<strong><?php esc_html_e( 'Safety Enforcement Gate:', 'site-checkup-pro' ); ?></strong>
					<p><?php esc_html_e( 'The task you selected modifies critical server configuration files (.htaccess or wp-config.php). To prevent accidental lockout, our agency SOP requires a verified backup within the last 48 hours.', 'site-checkup-pro' ); ?></p>
				</div>
			</div>

			<p id="wpsg-backup-modal-msg"><?php esc_html_e( 'No recent backup was found within the last 48 hours.', 'site-checkup-pro' ); ?></p>

			<div class="wpsg-backup-options-box">
				<div class="wpsg-backup-option">
					<h4><?php esc_html_e( 'Option 1: Backup via Plugin', 'site-checkup-pro' ); ?></h4>
					<p><?php esc_html_e( 'Open your installed backup plugin and take a snapshot right now.', 'site-checkup-pro' ); ?></p>
					<a href="#" id="wpsg-backup-trigger-link" class="wpsg-btn wpsg-btn-outline" target="_blank">
						<span class="dashicons dashicons-external"></span> <span id="wpsg-backup-trigger-text"><?php esc_html_e( 'Open Backup Plugin', 'site-checkup-pro' ); ?></span>
					</a>
				</div>

				<div class="wpsg-backup-option">
					<h4><?php esc_html_e( 'Option 2: Host / cPanel Snapshot', 'site-checkup-pro' ); ?></h4>
					<p><?php esc_html_e( 'If you have taken a host-level snapshot via cPanel/hosting panel in the last 48 hours, you can confirm it below.', 'site-checkup-pro' ); ?></p>
					<button type="button" class="wpsg-btn wpsg-btn-secondary" id="wpsg-btn-confirm-manual-backup-modal">
						<span class="dashicons dashicons-saved"></span> <?php esc_html_e( 'I Have a Recent Host Backup', 'site-checkup-pro' ); ?>
					</button>
				</div>
			</div>
		</div>

		<div class="wpsg-modal-footer">
			<button type="button" class="wpsg-btn wpsg-btn-outline" data-close-modal><?php esc_html_e( 'Cancel', 'site-checkup-pro' ); ?></button>
		</div>
	</div>
</div>
