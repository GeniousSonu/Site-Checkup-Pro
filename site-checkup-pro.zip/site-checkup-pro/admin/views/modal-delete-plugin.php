<?php
/**
 * Modal: Quarantine & Delete Plugin
 *
 * Confirms plugin deletion after creating a full zip archive in wpsg-backups/plugins/.
 *
 * @package SiteCheckupPro
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wpsg-modal-overlay" id="wpsg-modal-delete-plugin" style="display: none;">
	<div class="wpsg-modal">
		<div class="wpsg-modal-header">
			<div class="wpsg-modal-title-row">
				<span class="dashicons dashicons-trash"></span>
				<h3><?php esc_html_e( 'Confirm Safe Plugin Removal', 'site-checkup-pro' ); ?></h3>
			</div>
			<button type="button" class="wpsg-modal-close" data-close-modal>&times;</button>
		</div>

		<div class="wpsg-modal-body">
			<p class="wpsg-modal-desc">
				<?php esc_html_e( 'You are about to remove an unwanted development/migration plugin from this site.', 'site-checkup-pro' ); ?>
			</p>

			<div class="wpsg-delete-target-card">
				<strong id="wpsg-delete-plugin-name">Plugin Name</strong>
				<span id="wpsg-delete-plugin-slug" class="wpsg-badge wpsg-badge-subtle">plugin-slug</span>
			</div>

			<div class="wpsg-callout wpsg-callout-info">
				<span class="dashicons dashicons-archive"></span>
				<div>
					<strong><?php esc_html_e( 'Automatic ZIP Backup Protection:', 'site-checkup-pro' ); ?></strong>
					<p><?php esc_html_e( 'Before deletion, the entire plugin directory will be archived into a compressed ZIP file under wp-content/uploads/wpsg-backups/plugins/. You can undo and restore the plugin anytime.', 'site-checkup-pro' ); ?></p>
				</div>
			</div>
		</div>

		<div class="wpsg-modal-footer">
			<button type="button" class="wpsg-btn wpsg-btn-outline" data-close-modal><?php esc_html_e( 'Cancel', 'site-checkup-pro' ); ?></button>
			<button type="button" class="wpsg-btn wpsg-btn-danger" id="wpsg-btn-confirm-delete-plugin">
				<span class="dashicons dashicons-trash"></span> <?php esc_html_e( 'Backup to ZIP & Delete Plugin', 'site-checkup-pro' ); ?>
			</button>
		</div>
	</div>
</div>
