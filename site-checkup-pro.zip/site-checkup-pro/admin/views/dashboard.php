<?php
/**
 * Main Check-up Dashboard View
 *
 * @package SiteCheckupPro
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$registry      = WPSG_Task_Registry::get_instance();
$sections      = WPSG_Task_Registry::$sections;
$server_type   = WPSG_Htaccess_Manager::get_server_type();
$has_htaccess  = WPSG_Htaccess_Manager::supports_htaccess();
$backup_status = WPSG_Backup_Guard::get_backup_status();
?>

<div class="wrap wpsg-wrap" id="wpsg-app">
	<!-- Top Navigation Header -->
	<header class="wpsg-header">
		<div class="wpsg-header-brand">
			<span class="wpsg-logo-icon dashicons dashicons-shield"></span>
			<div class="wpsg-brand-text">
				<h1 class="wpsg-title"><?php esc_html_e( 'Site Checkup Pro', 'site-checkup-pro' ); ?></h1>
				<p class="wpsg-subtitle"><?php esc_html_e( 'Agency SOP Security Checklist & Hardening Orchestrator', 'site-checkup-pro' ); ?></p>
			</div>
		</div>

		<div class="wpsg-header-actions">
			<button type="button" class="wpsg-btn wpsg-btn-outline" id="wpsg-btn-confirm-backup" title="<?php esc_attr_e( 'Record that a manual backup was just performed', 'site-checkup-pro' ); ?>">
				<span class="dashicons dashicons-cloud"></span> <?php esc_html_e( 'Confirm Host Backup', 'site-checkup-pro' ); ?>
			</button>
			<button type="button" class="wpsg-btn wpsg-btn-outline" id="wpsg-btn-update-baseline" title="<?php esc_attr_e( 'Accept current administrators and URLs as the trusted baseline', 'site-checkup-pro' ); ?>">
				<span class="dashicons dashicons-saved"></span> <?php esc_html_e( 'Trust Current Baseline', 'site-checkup-pro' ); ?>
			</button>
			<button type="button" class="wpsg-btn wpsg-btn-primary" id="wpsg-btn-batch-run">
				<span class="dashicons dashicons-controls-play"></span> <?php esc_html_e( 'Run All Safe Tasks', 'site-checkup-pro' ); ?>
			</button>
		</div>
	</header>

	<!-- Live Batch Progress Banner (Hidden by default) -->
	<div class="wpsg-batch-banner" id="wpsg-batch-banner" style="display: none;">
		<div class="wpsg-batch-info">
			<span class="wpsg-spinner"></span>
			<span class="wpsg-batch-text" id="wpsg-batch-text"><?php esc_html_e( 'Executing safe tasks sequentially...', 'site-checkup-pro' ); ?></span>
			<span class="wpsg-batch-count" id="wpsg-batch-count">0 / 0</span>
		</div>
		<div class="wpsg-progress-track">
			<div class="wpsg-progress-bar" id="wpsg-batch-progress" style="width: 0%;"></div>
		</div>
		<button type="button" class="wpsg-btn wpsg-btn-sm wpsg-btn-subtle" id="wpsg-batch-cancel"><?php esc_html_e( 'Stop', 'site-checkup-pro' ); ?></button>
	</div>

	<!-- KPI Summary Bar -->
	<section class="wpsg-kpi-grid">
		<!-- KPI 1: SOP Coverage -->
		<div class="wpsg-kpi-card">
			<div class="wpsg-kpi-header">
				<span class="wpsg-kpi-label"><?php esc_html_e( 'SOP Coverage', 'site-checkup-pro' ); ?></span>
				<span class="dashicons dashicons-chart-pie"></span>
			</div>
			<div class="wpsg-kpi-value-row">
				<span class="wpsg-kpi-value" id="wpsg-kpi-coverage">0%</span>
				<span class="wpsg-kpi-sub" id="wpsg-kpi-fraction">0 / 0 tasks</span>
			</div>
			<div class="wpsg-progress-track">
				<div class="wpsg-progress-bar wpsg-bar-primary" id="wpsg-coverage-bar" style="width: 0%;"></div>
			</div>
			<p class="wpsg-kpi-disclaimer">
				<?php esc_html_e( '*Reflects adherence to internal hardening SOP checklist; not a penetration-test result or guarantee.', 'site-checkup-pro' ); ?>
			</p>
		</div>

		<!-- KPI 2: Server Environment -->
		<div class="wpsg-kpi-card">
			<div class="wpsg-kpi-header">
				<span class="wpsg-kpi-label"><?php esc_html_e( 'Web Server', 'site-checkup-pro' ); ?></span>
				<span class="dashicons dashicons-networking"></span>
			</div>
			<div class="wpsg-kpi-value-row">
				<span class="wpsg-kpi-value" id="wpsg-kpi-server"><?php echo esc_html( strtoupper( $server_type ) ); ?></span>
			</div>
			<p class="wpsg-kpi-meta">
				<?php if ( $has_htaccess ) : ?>
					<span class="wpsg-badge wpsg-badge-done"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( '.htaccess supported', 'site-checkup-pro' ); ?></span>
				<?php else : ?>
					<span class="wpsg-badge wpsg-badge-attention"><span class="dashicons dashicons-info"></span> <?php esc_html_e( 'Nginx (Snippets Provided)', 'site-checkup-pro' ); ?></span>
				<?php endif; ?>
			</p>
			<p class="wpsg-kpi-desc">
				<?php echo $has_htaccess ? esc_html__( 'Apache/LiteSpeed detected. One-click rules will write to .htaccess safely.', 'site-checkup-pro' ) : esc_html__( 'Nginx detected. .htaccess tasks will show copyable Nginx configuration blocks.', 'site-checkup-pro' ); ?>
			</p>
		</div>

		<!-- KPI 3: Backup Status -->
		<div class="wpsg-kpi-card">
			<div class="wpsg-kpi-header">
				<span class="wpsg-kpi-label"><?php esc_html_e( 'Backup Protection', 'site-checkup-pro' ); ?></span>
				<span class="dashicons dashicons-backup"></span>
			</div>
			<div class="wpsg-kpi-value-row">
				<span class="wpsg-kpi-value" id="wpsg-kpi-backup-name">
					<?php echo ! empty( $backup_status['plugin_name'] ) ? esc_html( $backup_status['plugin_name'] ) : esc_html__( 'No Plugin Detected', 'site-checkup-pro' ); ?>
				</span>
			</div>
			<p class="wpsg-kpi-meta">
				<?php if ( ! empty( $backup_status['is_recent'] ) ) : ?>
					<span class="wpsg-badge wpsg-badge-done"><span class="dashicons dashicons-yes-alt"></span> <?php printf( esc_html__( 'Recent (%s hrs ago)', 'site-checkup-pro' ), esc_html( $backup_status['age_hours'] ) ); ?></span>
				<?php else : ?>
					<span class="wpsg-badge wpsg-badge-failed"><span class="dashicons dashicons-warning"></span> <?php esc_html_e( 'Over 48h / Missing', 'site-checkup-pro' ); ?></span>
				<?php endif; ?>
			</p>
			<p class="wpsg-kpi-desc">
				<?php esc_html_e( 'File-modifying tasks require a verified backup within 48h before execution.', 'site-checkup-pro' ); ?>
			</p>
		</div>

		<!-- KPI 4: Recurring Reminders -->
		<div class="wpsg-kpi-card">
			<div class="wpsg-kpi-header">
				<span class="wpsg-kpi-label"><?php esc_html_e( 'SOP Reminders Due', 'site-checkup-pro' ); ?></span>
				<span class="dashicons dashicons-clock"></span>
			</div>
			<div class="wpsg-kpi-value-row">
				<span class="wpsg-kpi-value" id="wpsg-kpi-reminders">0</span>
				<span class="wpsg-kpi-sub"><?php esc_html_e( 'scheduled', 'site-checkup-pro' ); ?></span>
			</div>
			<p class="wpsg-kpi-desc">
				<?php esc_html_e( 'Tracks 15-day credential rotations, GSC rechecks, and manual audit cycles.', 'site-checkup-pro' ); ?>
			</p>
		</div>
	</section>

	<!-- Tab Navigation & Filters -->
	<div class="wpsg-toolbar">
		<nav class="wpsg-tabs" role="tablist">
			<button type="button" class="wpsg-tab active" data-tab="all">
				<span class="dashicons dashicons-list-view"></span> <?php esc_html_e( 'All Tasks', 'site-checkup-pro' ); ?>
			</button>
			<?php foreach ( $sections as $s_key => $s_meta ) : ?>
				<button type="button" class="wpsg-tab" data-tab="<?php echo esc_attr( $s_key ); ?>">
					<span class="dashicons <?php echo esc_attr( $s_meta['icon'] ); ?>"></span>
					<?php echo esc_html( $s_meta['label'] ); ?>
				</button>
			<?php endforeach; ?>
			<button type="button" class="wpsg-tab" data-tab="audit_trail">
				<span class="dashicons dashicons-portfolio"></span> <?php esc_html_e( 'Audit Trail', 'site-checkup-pro' ); ?>
			</button>
		</nav>

		<div class="wpsg-filters">
			<select id="wpsg-filter-level" class="wpsg-select">
				<option value=""><?php esc_html_e( 'All Automation Levels', 'site-checkup-pro' ); ?></option>
				<option value="A_instant"><?php esc_html_e( 'Level A: Safe / Instant', 'site-checkup-pro' ); ?></option>
				<option value="A_files"><?php esc_html_e( 'Level A: Config / File Writers', 'site-checkup-pro' ); ?></option>
				<option value="B"><?php esc_html_e( 'Level B: Guided Actions', 'site-checkup-pro' ); ?></option>
				<option value="C"><?php esc_html_e( 'Level C: Manual / Reminders', 'site-checkup-pro' ); ?></option>
			</select>

			<select id="wpsg-filter-status" class="wpsg-select">
				<option value=""><?php esc_html_e( 'All Statuses', 'site-checkup-pro' ); ?></option>
				<option value="pending"><?php esc_html_e( 'Pending', 'site-checkup-pro' ); ?></option>
				<option value="done"><?php esc_html_e( 'Completed', 'site-checkup-pro' ); ?></option>
				<option value="attention"><?php esc_html_e( 'Needs Attention', 'site-checkup-pro' ); ?></option>
				<option value="failed"><?php esc_html_e( 'Failed', 'site-checkup-pro' ); ?></option>
				<option value="not_applicable"><?php esc_html_e( 'Not Applicable', 'site-checkup-pro' ); ?></option>
			</select>
		</div>
	</div>

	<!-- Main Tasks Container -->
	<main class="wpsg-main-content">
		<!-- Section Header (dynamic) -->
		<div class="wpsg-section-banner" id="wpsg-section-banner">
			<h2 class="wpsg-section-title" id="wpsg-section-title"><?php esc_html_e( 'Global Security Check-up Tasks', 'site-checkup-pro' ); ?></h2>
			<p class="wpsg-section-desc" id="wpsg-section-desc"><?php esc_html_e( 'Review and run security tasks sequentially or filter by SOP section.', 'site-checkup-pro' ); ?></p>
		</div>

		<!-- Tasks Table -->
		<div class="wpsg-table-wrapper" id="wpsg-tasks-table-wrapper">
			<table class="wpsg-table" id="wpsg-tasks-table">
				<thead>
					<tr>
						<th class="wpsg-col-status"><?php esc_html_e( 'Status', 'site-checkup-pro' ); ?></th>
						<th class="wpsg-col-level"><?php esc_html_e( 'Level', 'site-checkup-pro' ); ?></th>
						<th class="wpsg-col-task"><?php esc_html_e( 'Task & SOP Description', 'site-checkup-pro' ); ?></th>
						<th class="wpsg-col-lastrun"><?php esc_html_e( 'Last Checked', 'site-checkup-pro' ); ?></th>
						<th class="wpsg-col-actions"><?php esc_html_e( 'Action', 'site-checkup-pro' ); ?></th>
					</tr>
				</thead>
				<tbody id="wpsg-tasks-tbody">
					<!-- Populated dynamically via admin.js -->
					<tr class="wpsg-loading-row">
						<td colspan="5">
							<div class="wpsg-loading-state">
								<span class="wpsg-spinner"></span>
								<p><?php esc_html_e( 'Loading checklist tasks and live status...', 'site-checkup-pro' ); ?></p>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>

		<!-- Audit Log View Container (Hidden by default, shown on audit_trail tab) -->
		<div class="wpsg-audit-view" id="wpsg-audit-view" style="display: none;">
			<div class="wpsg-audit-header">
				<h3><?php esc_html_e( 'Security Audit Trail', 'site-checkup-pro' ); ?></h3>
				<p><?php esc_html_e( 'Timestamped history of all hardening actions, undo operations, and status modifications.', 'site-checkup-pro' ); ?></p>
			</div>
			<table class="wpsg-table" id="wpsg-audit-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Timestamp', 'site-checkup-pro' ); ?></th>
						<th><?php esc_html_e( 'Task ID', 'site-checkup-pro' ); ?></th>
						<th><?php esc_html_e( 'Action', 'site-checkup-pro' ); ?></th>
						<th><?php esc_html_e( 'User', 'site-checkup-pro' ); ?></th>
						<th><?php esc_html_e( 'Result', 'site-checkup-pro' ); ?></th>
						<th><?php esc_html_e( 'Message / Details', 'site-checkup-pro' ); ?></th>
					</tr>
				</thead>
				<tbody id="wpsg-audit-tbody">
					<!-- Populated dynamically via admin.js -->
				</tbody>
			</table>
		</div>
	</main>

	<!-- Modals -->
	<?php include WPSG_PLUGIN_DIR . 'admin/views/modal-diff.php'; ?>
	<?php include WPSG_PLUGIN_DIR . 'admin/views/modal-nginx.php'; ?>
	<?php include WPSG_PLUGIN_DIR . 'admin/views/modal-backup.php'; ?>
	<?php include WPSG_PLUGIN_DIR . 'admin/views/modal-note.php'; ?>
	<?php include WPSG_PLUGIN_DIR . 'admin/views/modal-login-rename.php'; ?>
	<?php include WPSG_PLUGIN_DIR . 'admin/views/modal-delete-plugin.php'; ?>

</div>
