<?php
/**
 * Modal: Diff Preview
 *
 * Displays exact proposed changes before modifying server files (.htaccess, wp-config.php).
 *
 * @package SiteCheckupPro
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wpsg-modal-overlay" id="wpsg-modal-diff" style="display: none;">
	<div class="wpsg-modal wpsg-modal-lg">
		<div class="wpsg-modal-header">
			<div class="wpsg-modal-title-row">
				<span class="dashicons dashicons-visibility"></span>
				<h3 id="wpsg-diff-modal-title"><?php esc_html_e( 'Pre-Execution Diff Preview', 'site-checkup-pro' ); ?></h3>
			</div>
			<button type="button" class="wpsg-modal-close" data-close-modal>&times;</button>
		</div>

		<div class="wpsg-modal-body">
			<p class="wpsg-diff-intro">
				<?php esc_html_e( 'Review the exact configuration block that will be safely inserted into your server configuration using delimited markers.', 'site-checkup-pro' ); ?>
			</p>

			<div class="wpsg-diff-target-badge">
				<span class="dashicons dashicons-media-text"></span>
				<span id="wpsg-diff-file-target"><?php esc_html_e( 'Target: .htaccess', 'site-checkup-pro' ); ?></span>
			</div>

			<div class="wpsg-diff-box">
				<pre><code id="wpsg-diff-content" class="language-apache"></code></pre>
			</div>

			<div class="wpsg-callout wpsg-callout-info">
				<span class="dashicons dashicons-info"></span>
				<div>
					<strong><?php esc_html_e( 'Automated Safety Net:', 'site-checkup-pro' ); ?></strong>
					<?php esc_html_e( 'An automatic timestamped backup is created prior to saving. After applying, an internal self-test verifies site health and will automatically roll back if a 5xx error occurs.', 'site-checkup-pro' ); ?>
				</div>
			</div>
		</div>

		<div class="wpsg-modal-footer">
			<button type="button" class="wpsg-btn wpsg-btn-outline" data-close-modal><?php esc_html_e( 'Cancel', 'site-checkup-pro' ); ?></button>
			<button type="button" class="wpsg-btn wpsg-btn-primary" id="wpsg-btn-diff-confirm-run">
				<span class="dashicons dashicons-shield"></span> <?php esc_html_e( 'Apply Hardening Rule', 'site-checkup-pro' ); ?>
			</button>
		</div>
	</div>
</div>
