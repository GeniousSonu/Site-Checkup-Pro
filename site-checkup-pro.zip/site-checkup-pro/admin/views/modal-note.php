<?php
/**
 * Modal: Note & Schedule Reminder (Level C)
 *
 * Captures manual checklist notes and configures 15-day / 6-month reminders.
 *
 * @package SiteCheckupPro
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wpsg-modal-overlay" id="wpsg-modal-note" style="display: none;">
	<div class="wpsg-modal">
		<div class="wpsg-modal-header">
			<div class="wpsg-modal-title-row">
				<span class="dashicons dashicons-edit"></span>
				<h3 id="wpsg-note-modal-title"><?php esc_html_e( 'Manual Audit & Notes', 'site-checkup-pro' ); ?></h3>
			</div>
			<button type="button" class="wpsg-modal-close" data-close-modal>&times;</button>
		</div>

		<div class="wpsg-modal-body">
			<p id="wpsg-note-task-desc" class="wpsg-modal-desc"></p>

			<!-- Password Generator Tool for Credential Rotations -->
			<div class="wpsg-callout wpsg-callout-info" id="wpsg-passgen-box">
				<span class="dashicons dashicons-admin-network"></span>
				<div style="width: 100%;">
					<strong><?php esc_html_e( 'Credential Rotation Tool:', 'site-checkup-pro' ); ?></strong>
					<p><?php esc_html_e( 'Generate a secure 24-character password to update in cPanel/vault:', 'site-checkup-pro' ); ?></p>
					<div class="wpsg-input-prefix-row" style="margin-top: 8px;">
						<input type="text" id="wpsg-generated-pass" class="wpsg-input" readonly style="font-family: monospace; font-size: 13px; font-weight: 700; background: #ffffff;" placeholder="<?php esc_attr_e( 'Click Generate below...', 'site-checkup-pro' ); ?>" />
						<button type="button" class="wpsg-btn wpsg-btn-sm wpsg-btn-primary" id="wpsg-btn-gen-pass" style="border-radius: 0;">
							<span class="dashicons dashicons-update"></span> <?php esc_html_e( 'Generate', 'site-checkup-pro' ); ?>
						</button>
						<button type="button" class="wpsg-btn wpsg-btn-sm wpsg-btn-secondary" id="wpsg-btn-copy-pass" style="border-radius: 0;">
							<span class="dashicons dashicons-clipboard"></span> <?php esc_html_e( 'Copy', 'site-checkup-pro' ); ?>
						</button>
					</div>
				</div>
			</div>

			<div class="wpsg-form-group">
				<label class="wpsg-form-label" for="wpsg-task-note"><?php esc_html_e( 'Audit Notes / Vault Record:', 'site-checkup-pro' ); ?></label>
				<textarea id="wpsg-task-note" class="wpsg-textarea" rows="4" placeholder="<?php esc_attr_e( 'Record details, e.g. "cPanel password updated in 1Password vault by Alex on Sep 16".', 'site-checkup-pro' ); ?>"></textarea>
			</div>

			<div class="wpsg-form-group">
				<label class="wpsg-form-label" for="wpsg-task-reminder"><?php esc_html_e( 'Schedule Next Review / Rotation:', 'site-checkup-pro' ); ?></label>
				<select id="wpsg-task-reminder" class="wpsg-select">
					<option value="none"><?php esc_html_e( 'No reminder', 'site-checkup-pro' ); ?></option>
					<option value="15_days"><?php esc_html_e( 'Remind me in 15 days (SOP standard for credentials)', 'site-checkup-pro' ); ?></option>
					<option value="30_days"><?php esc_html_e( 'Remind me in 30 days', 'site-checkup-pro' ); ?></option>
					<option value="6_months"><?php esc_html_e( 'Remind me in 6 months (GSC URL removal review)', 'site-checkup-pro' ); ?></option>
				</select>
			</div>
		</div>

		<div class="wpsg-modal-footer">
			<button type="button" class="wpsg-btn wpsg-btn-outline" data-close-modal><?php esc_html_e( 'Cancel', 'site-checkup-pro' ); ?></button>
			<button type="button" class="wpsg-btn wpsg-btn-primary" id="wpsg-btn-save-note">
				<span class="dashicons dashicons-yes"></span> <?php esc_html_e( 'Mark Done & Save Notes', 'site-checkup-pro' ); ?>
			</button>
		</div>
	</div>
</div>
