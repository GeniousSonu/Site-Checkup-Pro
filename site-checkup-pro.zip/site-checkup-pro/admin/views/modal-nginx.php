<?php
/**
 * Modal: Nginx Snippet
 *
 * Displays equivalent Nginx configuration directives for hosts running Nginx.
 *
 * @package SiteCheckupPro
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wpsg-modal-overlay" id="wpsg-modal-nginx" style="display: none;">
	<div class="wpsg-modal">
		<div class="wpsg-modal-header">
			<div class="wpsg-modal-title-row">
				<span class="dashicons dashicons-networking"></span>
				<h3><?php esc_html_e( 'Nginx Configuration Snippet', 'site-checkup-pro' ); ?></h3>
			</div>
			<button type="button" class="wpsg-modal-close" data-close-modal>&times;</button>
		</div>

		<div class="wpsg-modal-body">
			<div class="wpsg-callout wpsg-callout-warning">
				<span class="dashicons dashicons-warning"></span>
				<div>
					<strong><?php esc_html_e( 'Nginx Environment Detected', 'site-checkup-pro' ); ?></strong>
					<p><?php esc_html_e( 'Your server does not parse .htaccess files. Instead of a false positive, apply the equivalent directive directly inside your Nginx server block (or provide this snippet to your hosting support).', 'site-checkup-pro' ); ?></p>
				</div>
			</div>

			<label class="wpsg-form-label" for="wpsg-nginx-code"><?php esc_html_e( 'Nginx Server Directive:', 'site-checkup-pro' ); ?></label>
			<div class="wpsg-diff-box">
				<pre><code id="wpsg-nginx-code" class="language-nginx"></code></pre>
			</div>
		</div>

		<div class="wpsg-modal-footer">
			<button type="button" class="wpsg-btn wpsg-btn-outline" data-close-modal><?php esc_html_e( 'Close', 'site-checkup-pro' ); ?></button>
			<button type="button" class="wpsg-btn wpsg-btn-primary" id="wpsg-btn-copy-nginx">
				<span class="dashicons dashicons-clipboard"></span> <?php esc_html_e( 'Copy Nginx Snippet', 'site-checkup-pro' ); ?>
			</button>
		</div>
	</div>
</div>
