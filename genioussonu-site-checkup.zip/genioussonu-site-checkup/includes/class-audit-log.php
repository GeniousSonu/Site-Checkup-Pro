<?php
/**
* Audit Log Handler with Sensitive Data Redaction
 *
 *
 * @package GeniousSonu_Site_Checkup
 * @author  SK Sahinur Islam <https://www.genioussonu.me/>
 * @link    https://github.com/GeniousSonu/
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WPSG_Audit_Log
 */
class WPSG_Audit_Log {

	/**
	 * Record an entry into the audit log table.
	 *
	 * @param string $task_id         Task ID.
	 * @param string $action          Action performed (run, undo, mark_done, note_update).
	 * @param mixed  $before_snapshot State before action.
	 * @param mixed  $after_snapshot  State after action.
	 * @param string $result          Result ('success' or 'failed').
	 * @param string $message         Descriptive message.
	 * @return int|false Insert ID or false on failure.
	 */
	public static function log( $task_id, $action, $before_snapshot = null, $after_snapshot = null, $result = 'success', $message = '' ) {
		global $wpdb;

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'insert' ) ) {
			return false;
		}

		$table_name = wpsg_get_table_name( 'audit_log' );
		if ( false === $table_name ) {
			return false;
		}
		$table_name = esc_sql( $table_name );
		$user_id    = get_current_user_id();

		// Sanitize snapshots to guarantee zero sensitive keys or passwords are saved.
		$sanitized_before = self::sanitize_snapshot( $task_id, $before_snapshot );
		$sanitized_after  = self::sanitize_snapshot( $task_id, $after_snapshot );

		// Log forging defense: strip newlines and control characters.
		$clean_message = preg_replace( '/[\r\n\t\x00-\x1F\x7F]+/', ' ', (string) $message );
		$clean_message = sanitize_text_field( trim( $clean_message ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$inserted = $wpdb->insert(
			$table_name,
			array(
				'task_id'         => sanitize_key( $task_id ),
				'action'          => sanitize_text_field( $action ),
				'user_id'         => absint( $user_id ),
				'before_snapshot' => $sanitized_before ? wp_json_encode( $sanitized_before ) : null,
				'after_snapshot'  => $sanitized_after ? wp_json_encode( $sanitized_after ) : null,
				'result'          => 'failed' === $result ? 'failed' : 'success',
				'message'         => $clean_message,
				'created_at'      => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s' ) // 8 fields: task_id, action, user_id, before_snapshot, after_snapshot, result, message, created_at
		);

		return $inserted ? ( isset( $wpdb->insert_id ) ? $wpdb->insert_id : true ) : false;
	}

	/**
	 * Sanitizes snapshot data to protect database credentials, salts, and secret keys.
	 *
	 * @param string $task_id Task ID.
	 * @param mixed  $data    Raw snapshot data.
	 * @return array|null Sanitized data array.
	 */
	public static function sanitize_snapshot( $task_id, $data ) {
		if ( empty( $data ) ) {
			return null;
		}

		// 1. Salt rotation: NEVER log old or new key material.
		if ( 'rotate_salts' === $task_id ) {
			return array(
				'salts_rotated' => true,
				'timestamp'     => current_time( 'mysql' ),
				'keys_count'    => 8,
			);
		}

		// 2. Config changes: Store only changed constant names + boolean states.
		if ( 'disable_file_edit' === $task_id || false !== strpos( $task_id, 'wp_config' ) ) {
			if ( is_array( $data ) ) {
				$clean = array();
				foreach ( $data as $k => $v ) {
					// Only allow specific recognized boolean flags.
					if ( in_array( $k, array( 'DISALLOW_FILE_EDIT', 'DISALLOW_FILE_MODS' ), true ) ) {
						$clean[ $k ] = (bool) $v;
					}
				}
				return ! empty( $clean ) ? $clean : array( 'constants_updated' => true );
			}
			return array( 'file_modified' => true );
		}

		// 3. Recursive scrub for any general snapshot arrays.
		if ( is_array( $data ) ) {
			return self::recursive_scrub( $data );
		}

		if ( is_string( $data ) ) {
			// If snapshot is raw string, never store if it looks like config/code.
			if ( false !== strpos( $data, 'DB_PASSWORD' ) || false !== strpos( $data, 'AUTH_KEY' ) ) {
				return array( 'raw_content' => '[REDACTED_FOR_SECURITY]' );
			}
			return array( 'summary' => sanitize_text_field( substr( $data, 0, 500 ) ) );
		}

		return array( 'value' => '[FILTERED]' );
	}

	/**
	 * Recursively scrub sensitive keys from an array.
	 *
	 * @param array $array Array to scrub.
	 * @return array Scrubbed array.
	 */
	private static function recursive_scrub( array $array ) {
		$sensitive_pattern = '/(pass|pwd|secret|key|salt|token|auth|cookie|hash)/i';
		$scrubbed          = array();

		foreach ( $array as $k => $v ) {
			if ( is_string( $k ) && preg_match( $sensitive_pattern, $k ) ) {
				$scrubbed[ $k ] = '[REDACTED]';
			} elseif ( is_array( $v ) ) {
				$scrubbed[ $k ] = self::recursive_scrub( $v );
			} else {
				$scrubbed[ $k ] = $v;
			}
		}

		return $scrubbed;
	}

	/**
	 * Get recent audit logs.
	 *
	 * @param int $limit  Number of records.
	 * @param int $offset Offset.
	 * @return array
	 */
	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- This query interpolates only allowlisted, escaped table/sort identifiers; data values are prepared.
	public static function get_logs( $limit = 50, $offset = 0, $orderby = 'created_at', $order = 'DESC' ) {
		global $wpdb;

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'get_results' ) || ! method_exists( $wpdb, 'prepare' ) ) {
			return array();
		}

		$table_name = wpsg_get_table_name( 'audit_log' );
		$users_table = wpsg_get_table_name( 'users' );
		if ( false === $table_name || false === $users_table ) {
			return array();
		}
		$table_name  = esc_sql( $table_name );
		$users_table = esc_sql( $users_table );
		$limit      = absint( $limit );
		$offset     = absint( $offset );

		$allowed_orderby = array(
			'created_at' => 'a.created_at',
			'task_id'    => 'a.task_id',
			'action'     => 'a.action',
			'result'     => 'a.result',
		);
		$sort_col = isset( $allowed_orderby[ $orderby ] ) ? $allowed_orderby[ $orderby ] : 'a.created_at';
		$sort_dir = 'ASC' === strtoupper( $order ) ? 'ASC' : 'DESC';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table identifiers are allowlisted and escaped; pagination values are prepared.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table and sort identifiers are allowlisted and escaped; pagination values are prepared.
				"SELECT a.*, u.user_login, u.display_name 
				FROM {$table_name} a
				LEFT JOIN {$users_table} u ON a.user_id = u.ID
				ORDER BY {$sort_col} {$sort_dir}
				LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);

		return is_array( $rows ) ? $rows : array();
	}
	// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

	/**
	 * Prune old audit logs older than a specified number of days (default: 365 days / 12 months).
	 *
	 * @param int $days Retention days.
	 * @return int Number of deleted rows.
	 */
	public static function prune_old_logs( $days = 365 ) {
		global $wpdb;

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'query' ) || ! method_exists( $wpdb, 'prepare' ) ) {
			return 0;
		}

		$table_name = wpsg_get_table_name( 'audit_log' );
		if ( false === $table_name ) {
			return 0;
		}
		$table_name = esc_sql( $table_name );
		$days       = absint( $days );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table identifier is allowlisted and escaped; retention days are prepared.
		$deleted = $wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table identifier is allowlisted and escaped; retention days are prepared.
				"DELETE FROM {$table_name} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
				$days
			)
		);

		return (int) $deleted;
	}
}
