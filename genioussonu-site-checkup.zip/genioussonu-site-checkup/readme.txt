=== GeniousSonu Site Checkup ===
Contributors: genioussonu
Author: SK Sahinur Islam
Author URI: https://www.genioussonu.me/
Plugin URI: https://www.genioussonu.me/plugin/genioussonu-site-checkup/
Tags: security, hardening, security audit, login security, firewall
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.3.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Security audit, site hardening checklist, and vulnerability scanner for WordPress. One-click safe hardening, login protection, and client reports.

== Description ==

**GeniousSonu Site Checkup** delivers professional **WordPress security** auditing and **site hardening** through an actionable, SOP-driven dashboard. Whether you need an instant **security checkup**, automated **hardening** for sensitive files and server headers, or a comprehensive **security audit** checklist across client installations, GeniousSonu Site Checkup organizes and executes your entire security workflow.

Rather than competing with or replacing mature firewalls and backup tools, GeniousSonu Site Checkup audits your environment, detects vulnerabilities, and applies verified, reversible **hardening** fixes with zero bloat. Automate safe security tasks, guide complex configurations with seamless plugin bridges, track routine credential rotations, and generate print-ready executive client audit reports:

* **Level A (Safe Automation & Scanners):** Disable XML-RPC, restrict unauthenticated REST user enumeration, hide PHP versions, enforce clickjacking protection (X-Frame-Options), MIME sniffing protection, HSTS, disable front-end `WP_DEBUG_DISPLAY`, audit file permissions (strict 640 baseline on `wp-config.php`), detect risky PHP `disable_functions` / `open_basedir`, check default `wp_` database prefix, external fingerprint scanner, and probe TLS protocols (`TLSv1.0` through `TLSv1.3`) and certificate chain depth.
* **Level B (Guided Actions & Bridges):** Seamlessly detects and bridges to mature, audited plugins (WPS Hide Login, Wordfence, Two-Factor Authentication, and Backup plugins) with recommended setting checklists. Generates RFC 9116 `/.well-known/security.txt` responsible disclosure contact files.
* **Level C (Manual Audits & Reminders):** Track 15-day credential rotations (cPanel, WordPress admin), quarterly (90-day) backup restore test rehearsals, staging site HTTP basic authentication, and 6-month Google Search Console URL removal reviews with automated dashboard reminder notices.
* **Level D (Executive Client Reports):** Generate print-ready HTML and PDF audit summaries detailing completed hardening, SOP coverage percentage, emergency incident-response escalation sheets, and timestamped audit logs for client handoff.

### Built with Enterprise Safeguards

* **Vulnerability Intelligence:** Queries the Patchstack vulnerability database API for installed plugins and themes with explicit confidence scoring (`high`, `medium`, `unverified/low`), ensuring custom or renamed plugins are never falsely reported as clean.
* **Server Environment Aware:** Automatically detects Apache/LiteSpeed vs Nginx. If your site runs on Nginx, .htaccess tasks display copyable Nginx server directives rather than false positive checkmarks.
* **Zero Secret Leakage:** Audit logs strictly redact passwords, auth keys, and database credentials. Constant changes log only boolean states; salt rotation logs zero key material.
* **Scoped REST API:** Options updates are restricted to a hardcoded whitelist with strict per-field sanitizers, preventing mass-assignment vulnerabilities.
* **Pre-Execution Diff Previews:** Inspect the exact marker-delimited configuration blocks before writing to `.htaccess` or `wp-config.php`.
* **Staging-Safe Health Checks:** Automatic loopback tests detect staging HTTP Basic Auth walls and only roll back upon true 5xx server errors.
* **Safe Plugin Deletion:** Unwanted migration tools are zipped to `wp-content/uploads/wpsg-backups/plugins/` before deletion, making Undo 100% genuine.
* **Fail-Safe Emergency Lockout Recovery:** Custom login renamer contains zero query-string backdoors. Recovery is exclusively controlled via the `WPSG_DISABLE_LOGIN_RENAME` constant in `wp-config.php`.

== Third Party Services ==

GeniousSonu Site Checkup connects to the following external third-party services to deliver security auditing and alerting functionality:

1. **WordPress.org APIs (`https://api.wordpress.org`)**
   - **Service & Purpose:** Used for core checksum validation (`/core/checksums/1.0/`) and verifying plugin directory status (`/plugins/info/1.0/`).
   - **Data Sent:** Current WordPress version, plugin slugs, and locale. No personally identifiable information (PII) or credentials are transmitted.
   - **Privacy Policy:** [WordPress.org Privacy Policy](https://wordpress.org/about/privacy/)

2. **Patchstack Vulnerability Database API (`https://patchstack.com`)**
   - **Service & Purpose:** Checks installed plugin and theme versions against the Patchstack vulnerability intelligence database to identify known CVEs.
   - **Explicit Consent Required:** Outbound queries to Patchstack require an explicit opt-in checkbox to be enabled in Plugin Settings per WordPress.org Guideline 7. If disabled, local plugin assessments are performed with zero outbound network calls.
   - **Data Sent:** Plugin and theme software slugs and version numbers. If configured by an administrator, an optional API authentication key is transmitted over HTTPS. No site visitor data, user credentials, or database contents are sent.
   - **Privacy Policy:** [Patchstack Privacy Policy](https://patchstack.com/privacy-policy/)
   - **Terms of Service:** [Patchstack Terms of Service](https://patchstack.com/terms-and-conditions/)

3. **User-Configured Alert Webhooks (Optional)**
   - **Service & Purpose:** When configured by an administrator, outbound security event notifications (e.g., brute-force lockouts, rogue admin detections) are dispatched to the customer's chosen webhook endpoint (e.g., Slack, Discord, or agency automation endpoint).
   - **Explicit Consent Required:** Outbound alert dispatch requires an explicit opt-in checkbox to be enabled in Plugin Settings per WordPress.org Guideline 7.
   - **Data Sent:** Factual incident event summaries (timestamp, alert type, sanitized technical message). Audit logs and webhook payloads strictly redact passwords, security salts, and authentication tokens.
   - **Terms & Privacy:** Governed by the destination endpoint provider chosen by the site administrator.

4. **GitHub Advisory Database (GHSA) (`https://api.github.com`)**
   - **Service & Purpose:** Queries the GitHub Advisory Database GraphQL/REST API for known security advisories affecting installed WordPress plugins and themes.
   - **Explicit Consent Required:** Disabled by default. Outbound requests require enabling the GHSA toggle in Settings per WordPress.org Guideline 7.
   - **Data Sent:** Software component slugs and versions. If supplied, an encrypted GitHub Personal Access Token is sent in the Authorization header. No personal user data or site contents are sent.
   - **Privacy Policy:** [GitHub Privacy Statement](https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement)
   - **Terms of Service:** [GitHub Terms of Service](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)

5. **Open Source Vulnerabilities (OSV) API (`https://api.osv.dev`)**
   - **Service & Purpose:** Queries the Google OSV distributed vulnerability database for security advisories across open-source ecosystems.
   - **Explicit Consent Required:** Disabled by default. Outbound requests require enabling the OSV toggle in Settings per WordPress.org Guideline 7.
   - **Data Sent:** Software component names and version strings. No user or visitor personal data is transmitted.
   - **Privacy Policy:** [Google Privacy Policy](https://policies.google.com/privacy)
   - **Terms of Service:** [OSV Terms of Service](https://osv.dev/faq)

6. **National Vulnerability Database (NVD) API (`https://services.nvd.nist.gov`)**
   - **Service & Purpose:** Queries the NIST National Vulnerability Database for Common Vulnerabilities and Exposures (CVE) intelligence and CVSS scores.
   - **Explicit Consent Required:** Disabled by default. Outbound requests require enabling the NVD toggle in Settings per WordPress.org Guideline 7.
   - **Data Sent:** Software identifiers and version parameters. Optional encrypted NVD API key sent if configured. No personally identifiable information is sent.
   - **Privacy Policy:** [NIST Privacy Policy](https://www.nist.gov/privacy-policy)

7. **CISA Known Exploited Vulnerabilities Catalog (KEV) (`https://www.cisa.gov`)**
   - **Service & Purpose:** Cross-references installed software with the CISA Known Exploited Vulnerabilities catalog to alert administrators of actively weaponized zero-days and exploits.
   - **Explicit Consent Required:** Disabled by default. Outbound requests require enabling the CISA KEV toggle in Settings per WordPress.org Guideline 7.
   - **Data Sent:** No site or user data is transmitted. Only a standard GET request to fetch the public catalog JSON feed.
   - **Privacy Policy:** [CISA Privacy Policy](https://www.cisa.gov/privacy-policy)

8. **WPScan WordPress Vulnerability Database (`https://wpscan.com`)**
   - **Service & Purpose:** Queries the WPScan vulnerability database for dedicated WordPress core, plugin, and theme security advisories.
   - **Explicit Consent Required:** Disabled by default. Outbound requests require enabling the WPScan toggle and providing an API key in Settings per WordPress.org Guideline 7.
   - **Data Sent:** Plugin and theme slugs and version numbers, along with the encrypted API token in request headers. No site content, visitor data, or user credentials are transmitted.
   - **Data Handling Notice:** In strict compliance with WPScan Terms of Service and data licensing, vulnerability intelligence data retrieved from WPScan is never permanently stored or cached on disk.
   - **Privacy Policy:** [Automattic Privacy Policy](https://automattic.com/privacy/)
   - **Terms of Service:** [WPScan Terms of Service](https://wpscan.com/terms/)

== Source Code & Development ==

The full, unminified source code for GeniousSonu Site Checkup is developed publicly on GitHub:
https://github.com/GeniousSonu/Site-Checkup-Pro

All JavaScript and CSS distributed in this plugin are 100% human-readable, unminified, locally bundled, and licensed under the GNU General Public License v2 or later per WordPress.org Guidelines 2 and 4.

== Installation ==

1. Upload the `genioussonu-site-checkup` folder to your `/wp-content/plugins/` directory, or upload the `.zip` archive via **Plugins &rarr; Add New &rarr; Upload Plugin**.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Navigate to the new **Site Checkup** top-level menu in your admin dashboard.
4. Review your initial SOP Coverage score and click **Run All Safe Tasks** to begin.

== Frequently Asked Questions ==

= What happens if my server runs Nginx instead of Apache? =
GeniousSonu Site Checkup detects Nginx server software (`$_SERVER['SERVER_SOFTWARE']`). Tasks that rely on `.htaccess` are marked as "Not Applicable on this Server" and feature a "View Nginx Snippet" button with 1-click copy for your server configuration.

= What if I get locked out using the custom login URL? =
Emergency recovery strictly requires filesystem access. Open `wp-config.php` via FTP, SSH, or your hosting control panel and add:
`define( 'WPSG_DISABLE_LOGIN_RENAME', true );`
This immediately deactivates the login renamer and restores access to the default `/wp-login.php`.

= Does GeniousSonu Site Checkup store my database password or salts in the audit log? =
No. Our audit logging system features an automated secret scrubber. Edits to `wp-config.php` only log constant names and boolean flags (e.g. `{"DISALLOW_FILE_EDIT": true}`). Salt rotations only log `{"salts_rotated": true}` with zero key material.

= Does this plugin work on WordPress Multisite? =
Version 1.0 is optimized for single-site agency workflows. On Multisite installations, settings and actions are strictly restricted to Super Administrators (`is_super_admin()`).

== Screenshots ==

1. Global Security Check-up dashboard with KPI summary bar and SOP Coverage score.
2. Accessible checklist table with colorblind-friendly SVG status badges and action triggers.
3. Pre-execution diff preview modal before writing to server configuration.
4. Client-facing executive SOP coverage report ready for PDF export with emergency incident response contacts.

== Changelog ==

= 1.3.1 =
* Fix: Parameterized and strictly escaped database table queries across migration readiness, DB health scanner, and task status lookup.
* Fix: Excluded internal agent and development markdown files (AGENTS.md, DEVELOPMENT.md, CONTRIBUTING.md, README.md, .agents/) from release packages.
* Hardening: Strengthened SQL query preparation and table validation matching strict injection-prevention guidelines.

= 1.3.0 =
* Feature: Multi-Source Vulnerability Intelligence — Unified threat feed integrating GitHub Advisory Database (GHSA), Google OSV, NIST NVD, CISA Known Exploited Vulnerabilities (KEV), and WPScan with strict Guideline 7 consent toggles and HKDF-encrypted API keys.
* Feature: Compound Version-Range Correlation — Semver boundary parser (`<`, `<=`, `>`, `>=`, `=`, `x`, compound `,` / `AND`) mapping vulnerability ranges accurately to installed plugin/theme versions.
* Feature: 3-State Fix Verification — Verifies vulnerability remediations (`done`, `applied_unverified`, `not_applied`) through live HTTP header and file checks.
* Feature: External Fingerprint & Information Disclosure Audit — Non-destructive loopback scanner probing for exposed backup dumps, sensitive files, and version leaks.
* Security: End-to-End Cryptographic Masking — HKDF-derived encryption at rest for all third-party API credentials with write-only REST submissions and masked getters.

= 1.2.0 =
* Feature: REST API Security Auditor — Complete discovery and permission callback inspection of all registered REST endpoints across core, active plugins, and themes with risk scoring and source reflection.
* Feature: Environment Badge Tagging — Persistent, color-coded admin bar badge (Production/Red, Staging/Amber, Development/Gray) with smart heuristics and hostname safety guards.
* Feature: Developer Diagnostic Snapshot — Sanitized Markdown system report export for GitHub issues and tickets with strict secret/salt/password redaction.
* Feature: WP-Cron Health Auditor — Inspection of scheduled background tasks with overdue stalled event detection (>600s late) and duplicate hook identification.
* Feature: Database Health Scanner & Bloat Cleanup — Detection of orphaned postmeta, orphaned usermeta, expired transients, and excess revisions with protected Level-B cleanup gated by administrator re-authentication and recent backup validation.
* Feature: Migration Serialization Readiness — Bounded scanning for absolute site URLs embedded inside serialized PHP objects with actionable WP-CLI search-replace guidance.
* Feature: Weekly Changelog Digest — Automated aggregation of available plugin and theme updates with upgrade notice highlighting, scheduled weekly digest alerts, and manual inspection.
* Integration: Self-Hosted Update Checker — Native support for update notifications and changelog viewing via YahnisElsts/plugin-update-checker library, cleanly isolated from WordPress.org releases.

= 1.0.2 =
* Fix: Resolve Run-button flicker and silent reversion on audit scanner tasks (File Permissions Audit, PHP Security Restrictions, Database Table Prefix, etc.) by ensuring all task response states (completed, unverified, findings-detected, failed) render explicit, visible UI states and appropriate action buttons.
* Fix: Restrict administrator password re-authentication exclusively to destructive, state-changing tasks (file modifications, plugin deletion, login URL renames, salt rotation, application password revocation) and exclude all read-only diagnostic scanners.
* Performance: Extend re-authentication token validity to a 30-minute trusted window after successful verification, eliminating repetitive password re-entry while retaining session binding and instant invalidation on logout or password change.
* UI: Retain updated task row visibility and add visual highlight animation upon manual scan execution during filtered status views.

= 1.0.1 =
* Fix: Prevent syntax corruption in wp-config.php during security salt rotation by removing unescaped quotes/backreferences and using safe callback replacement.
* Fix: Ensure full excision of empty marker blocks and directive-aware verification in WPSG_Htaccess_Manager.
* Fix: Ensure dbDelta schema updates run automatically on plugin version upgrades, not only on initial activation.
* Fix: Replace native browser confirm dialogs with accessible, branded custom modal dialogs.
* Fix: Enforce design tokens across entire admin stylesheet, eliminating hardcoded hex values.
* Fix: Resolve header case-sensitivity in loopback self-verification checks.

= 1.0.0 =
* Initial release.
* Added Task Registry with complete SOP checklist items.
* Implemented client-driven sequential batch runner.
* Added .htaccess and wp-config.php marker managers with health checks and diff preview.
* Integrated baseline drift scanner for rogue admins and wp_options.
* Added Nginx server detection and snippet exporter.
* Integrated Patchstack vulnerability database API with match-confidence scoring.
* Added multi-protocol TLS probe (`TLSv1.0` - `TLSv1.3`) and certificate chain depth verification.
* Added strict file permissions auditing (640 for `wp-config.php`, 644 files, 755 directories).
* Added RFC 9116 `/.well-known/security.txt` generator with document root containment.
* Added informational SPF/DKIM/DMARC domain authentication checker.
* Added 12-month audit log retention and 15-day / 90-day / 6-month scheduler.

== Credits ==

GeniousSonu Site Checkup is built and maintained by **[SK Sahinur Islam](https://www.genioussonu.me/)**.
* Author Website: [https://www.genioussonu.me/](https://www.genioussonu.me/)
* GitHub: [https://github.com/GeniousSonu/](https://github.com/GeniousSonu/)
* WordPress.org Profile: [https://profiles.wordpress.org/genioussonu/](https://profiles.wordpress.org/genioussonu/)
