<?php
/**
* Backup Plugin Integration Bridge
 *
 * Provides status and safe triggers for established backup solutions.
 *
 *
 * @package GeniousSonu_Site_Checkup
 * @author  SK Sahinur Islam <https://www.genioussonu.me/>
 * @link    https://github.com/GeniousSonu/
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WPSG_Backup_Bridge
 */
class WPSG_Backup_Bridge {

	/**
	 * Get detailed backup integration info.
	 *
	 * @return array
	 */
	public static function get_info() {
		return WPSG_Backup_Guard::get_backup_status();
	}

	/**
	 * Attempt to trigger a backup or provide deep-link if direct trigger is not safely available via public API.
	 *
	 * @return array
	 */
	public static function trigger_backup() {
		$status = WPSG_Backup_Guard::get_backup_status();

		if ( ! empty( $status['trigger_url'] ) ) {
			return array(
				'success'     => true,
				'redirect_url'=> $status['trigger_url'],
				'message'     => sprintf(
					/* translators: %s: plugin name */
					__( 'Please trigger a full backup via %s before continuing.', 'genioussonu-security-hardening-audit' ),
					$status['plugin_name'] ? $status['plugin_name'] : __( 'your backup plugin', 'genioussonu-security-hardening-audit' )
				),
			);
		}

		return array(
			'success' => false,
			'message' => __( 'No supported backup plugin detected to trigger automatic backup.', 'genioussonu-security-hardening-audit' ),
		);
	}
}
